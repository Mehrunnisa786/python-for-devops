#Taking backup

import shutil
import datetime
import os

def backup_files(source, destination):
    today = datetime.date.today()
    backup_files_name = os.path.join(destination, f"backup_{today},tar.gz")
    shutil.make_archive(destination, 'gztar', source)
source = "/Users/mehrunnisa/Documents/Linux/Pyhton"
destination = "/Users/mehrunnisa/Documents/Linux/Pyhton/backups"

backup_files(source, destination)
